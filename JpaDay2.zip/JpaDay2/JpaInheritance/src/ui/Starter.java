package ui;

import joined.JoinedDao;
import single.SingleDAO;

public class Starter {
	public static void main(String[] args) {
		new SingleDAO().insert();
		//new JoinedDao().doCrud();
	}

}
