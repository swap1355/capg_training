package single;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class SingleDAO {
	public void insert() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("inherit");
		EntityManager em = emf.createEntityManager();
		/*PermanentEmployeeST p = new PermanentEmployeeST();
		p.setEmpId(1001);
		p.setEmpName("jil");
		p.setSalary(76238);*/
		ContractEmployeeST c = new ContractEmployeeST();
		c.setEmpId(1002);
		c.setEmpName("john");
		c.setWages(343);
		em.getTransaction().begin();
		em.persist(c);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
		
		System.out.println("success"); 
		
		
	}

}
