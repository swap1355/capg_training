package single;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="cemployeetpc")
//@DiscriminatorValue("contract")
public class ContractEmployeeST extends EmployeeST{
	private  Integer wages;

	public Integer getWages() {
		return wages;
	}

	public void setWages(Integer wages) {
		this.wages = wages;
	}
	

}
