package single;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="pemployeetpc")
//@DiscriminatorValue("permanent")
public class PermanentEmployeeST extends EmployeeST{
	private Integer salary;

	public Integer getSalary() {
		return salary;
	}

	public void setSalary(Integer salary) {
		this.salary = salary;
	}
	

}
