package joined;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JoinedDao {
	public void doCrud() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("inherit");
		EntityManager em = emf.createEntityManager();
		ContractEmployeej c = new ContractEmployeej();
		c.setEmpId(1001);
		c.setEmpName("xxx");
		c.setWages(7378);
		em.getTransaction().begin();
		em.persist(c);
		em.getTransaction().commit();
		em.close();
		emf.close();
		System.out.println("done");
	}

}
