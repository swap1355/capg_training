package joined;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="pemployeej")
public class PermanentEmployeeJ extends Employeej {
	private Integer salary;

	public Integer getSalary() {
		return salary;
	}

	public void setSalary(Integer salary) {
		this.salary = salary;
	}

}
