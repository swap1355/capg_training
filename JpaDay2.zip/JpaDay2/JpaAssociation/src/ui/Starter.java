package ui;

import manytomany.ManyToManyDao;
import manytoone.ManyToOneDao;
import onetoone.OneToOneDao;

public class Starter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//new OneToOneDao().doCrud();
		//new managed removed detached
		
		//new ManyToOneDao().doCrud();
		new ManyToManyDao().doCrud();

	}

}
