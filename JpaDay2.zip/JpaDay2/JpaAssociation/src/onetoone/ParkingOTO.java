package onetoone;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="park_oto")
public class ParkingOTO {
	@Id
	private Integer parkingId;
	private String buildingName;
	@OneToOne(mappedBy="parking")
	private EmployeeOTO emp;
	
	
	public EmployeeOTO getEmp() {
		return emp;
	}
	public void setEmp(EmployeeOTO emp) {
		this.emp = emp;
	}
	public Integer getParkingId() {
		return parkingId;
	}
	public void setParkingId(Integer parkingId) {
		this.parkingId = parkingId;
	}
	public String getBuildingName() {
		return buildingName;
	}
	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}
	
	

}
