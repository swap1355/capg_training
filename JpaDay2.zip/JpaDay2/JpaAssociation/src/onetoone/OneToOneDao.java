package onetoone;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class OneToOneDao {
	
	public void doCrud() {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Association");
		EntityManager em = emf.createEntityManager();
		
		/*ParkingOTO park = new ParkingOTO();
		park.setParkingId(101);
		park.setBuildingName("B1");
		
		EmployeeOTO emp = new EmployeeOTO();
		emp.setEmpId(1001);
		emp.setEmpName("Mike");
		emp.setParking(park);
		em.getTransaction().begin();
		em.persist(emp);
		em.getTransaction().commit();*/
		
		
		/*EmployeeOTO emp=em.find(EmployeeOTO.class, 1001);
		System.out.println("name "+emp.getEmpName());
		System.out.println("pid" + emp.getParking().getParkingId());
		System.out.println("bname "+emp.getParking().getBuildingName());
		em.getTransaction().begin();
		em.remove(emp);
		em.getTransaction().commit();*/
		
		
		/*ParkingOTO park = new ParkingOTO();
		park.setParkingId(101);
		park.setBuildingName("B1");*/
		
		/*ParkingOTO park = em.find(ParkingOTO.class, 101);
		
		EmployeeOTO emp = new EmployeeOTO();
		emp.setEmpId(1001);
		emp.setEmpName("Mike");
		emp.setParking(park);
		
		
		em.getTransaction().begin();
		em.persist(emp);
		em.getTransaction().commit();
		
		em.clear();*/
		/*EmployeeOTO emp = em.find(EmployeeOTO.class,1001);
		emp.setParking(null);
		em.getTransaction().begin();
		em.remove(emp);
		em.getTransaction().commit();
		*/
		
		ParkingOTO park = em.find(ParkingOTO.class, 101);
		
		System.out.println(park.getEmp().getEmpName());
		
		em.close();
		emf.close();
		
		System.out.println("deleted successfully");
	}

}
