package manytomany;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="course")
public class CourseMTM {
	@Id
	private Integer courseId;
	private String courseName;
	@ManyToMany(mappedBy="courses")
	private List<StudentMTM>students;
	public Integer getCourseId() {
		return courseId;
	}
	public void setCourseId(Integer courseId) {
		this.courseId = courseId;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public List<StudentMTM> getStudents() {
		return students;
	}
	public void setStudents(List<StudentMTM> students) {
		this.students = students;
	}
	

}
