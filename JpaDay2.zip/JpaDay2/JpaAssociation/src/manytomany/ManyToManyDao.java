package manytomany;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class ManyToManyDao {
	public void doCrud() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Association");
		EntityManager em = emf.createEntityManager();
		CourseMTM c1 = new CourseMTM();
		c1.setCourseId(101);
		c1.setCourseName("hr");
		CourseMTM c2 = new CourseMTM();
		c2.setCourseId(102);
		c2.setCourseName("Fin");
		
		List<CourseMTM> list = new ArrayList<>();
		list.add(c1);
		list.add(c2);
		
		
		StudentMTM student = new StudentMTM();
		student.setStudentId(1001);
		student.setStudentName("Jack");
		student.setCourses(list);
		em.getTransaction().begin();
		em.persist(student);
		em.getTransaction().commit();
		em.close();
		emf.close();
		System.out.println("success");
		
	}

}
