package manytomany;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="student")
public class StudentMTM {
	@Id
	private Integer studentId;
	private String studentName;
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name="student_course",
	joinColumns=@JoinColumn(name="sid"), 
	inverseJoinColumns=@JoinColumn(name="cid"))
	private List<CourseMTM> courses;
	
	public Integer getStudentId() {
		return studentId;
	}
	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public List<CourseMTM> getCourses() {
		return courses;
	}
	public void setCourses(List<CourseMTM> courses) {
		this.courses = courses;
	}
	

}
