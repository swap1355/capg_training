package manytoone;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="dept_mto")
public class DepartmentMTM {
	@Id
	private Integer deptId;
	@Column(name="name")
	private String deptName;
	@OneToMany(mappedBy="dept")
	private List<EmployeeMTM> employees;
	
	public Integer getDeptId() {
		return deptId;
	}
	public void setDeptId(Integer deptId) {
		this.deptId = deptId;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public List<EmployeeMTM> getEmployees() {
		return employees;
	}
	public void setEmployees(List<EmployeeMTM> employees) {
		this.employees = employees;
	}
	

}
