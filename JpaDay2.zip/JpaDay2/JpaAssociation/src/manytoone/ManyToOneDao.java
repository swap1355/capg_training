package manytoone;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class ManyToOneDao {
	
	public void doCrud() {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Association");
		EntityManager em = emf.createEntityManager();
		/*DepartmentMTM dept = new DepartmentMTM();
		dept.setDeptId(101);
		dept.setDeptName("Acc");
		em.getTransaction().begin();
		em.persist(dept);
		em.getTransaction().commit();	*/
		
		/*DepartmentMTM dept = em.find(DepartmentMTM.class, 101);
		EmployeeMTM emp = new EmployeeMTM();
		emp.setEmpId(1002);
		emp.setEmpName("Riya");
		emp.setSalary(36373);
		emp.setDept(dept);
		em.getTransaction().begin();		
		em.persist(emp);
		em.getTransaction().commit();*/
		
		
		DepartmentMTM dept=em.find(DepartmentMTM.class, 101);
		
		System.out.println(dept.getDeptName());
	List<EmployeeMTM> list = dept.getEmployees();
	for (EmployeeMTM employeeMTM : list) {
		System.out.println(employeeMTM.getEmpName());
		
	}
		
		
		/*EmployeeMTM emp = em.find(EmployeeMTM.class, 1003);
		
		//System.out.println(emp.getDept().getDeptName());
		em.getTransaction().begin();
		emp.setDept(dept);
		em.getTransaction().commit();*/
		
		System.out.println("success");
		em.close();
		emf.close();
	}

}
